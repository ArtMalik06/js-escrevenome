function setup() {
  createCanvas(600, 600);
  background("lightgray");
}

function draw() {
  stroke ("gold");
  fill ("red");
  
  if (mouseIsPressed){
    rect(mouseX, mouseY, 10, 10);
}
  
}